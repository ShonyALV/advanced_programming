#include "user.h"

/**
 * Creates a new User with the given name and no friends.
 */
User::User(const std::string& name)
  : _name(name)
  , _friends(nullptr)
  , _size(0)
  , _capacity(0)
{
}

/**
 * Adds a friend to this User's list of friends.
 * @param name The name of the friend to add.
 */
void
User::add_friend(const std::string& name)
{
  if (_size == _capacity) {
    _capacity = 2 * _capacity + 1;
    std::string* newFriends = new std::string[_capacity]; 
    for (size_t i = 0; i < _size; ++i) {
      newFriends[i] = _friends[i];
    }
    delete[] _friends; 
    _friends = newFriends;
  }

  _friends[_size++] = name;
}

/**
 * Returns the name of this User.
 */
std::string
User::get_name() const
{
  return _name;
}

/**
 * Returns the number of friends this User has.
 */
size_t
User::size() const
{
  return _size;
}

/**
 * Sets the friend at the given index to the given name.
 * @param index The index of the friend to set.
 * @param name The name to set the friend to.
 */
void User::set_friend(size_t index, const std::string& name)
{
  _friends[index] = name;
}


std::ostream& operator<<(std::ostream& output_stream, const User& user){
    output_stream << "User(name=" << user._name << ", friends=[";
    for (size_t i = 0; i < user._size; ++i) {
        output_stream << user._friends[i];
        if (i < user._size - 1) {
            output_stream << ", ";
        };
    };
    output_stream << "])";
    return output_stream;
}

User& User::operator+=(User& other_user) {
  this->add_friend(other_user.get_name());
  other_user.add_friend(this->_name);
  return *this;
}

bool User::operator<(const User& other_user) const {
  return _name < other_user._name;
}

User::User(const User& other_user)
  : _name(other_user._name),
  _size(other_user._size),
  _capacity(other_user._capacity)
{
  if (other_user._capacity > 0) {
    _friends = new std::string[other_user._capacity]; 
    for (size_t i = 0; i < other_user._size; ++i) {
      _friends[i] = other_user._friends[i]; 
    }
  } else {
    _friends = nullptr; 
  }
}

User& User::operator=(const User& other_user) {
  if (this == &other_user) {
    return *this; // Evita la autoasignación
  }

  delete[] _friends;
  _name = other_user._name;
  _size = other_user._size;
  _capacity = other_user._capacity;
    
  if (_capacity > 0) {
    _friends = new std::string[_capacity];
    for (size_t i = 0; i < _size; i++) {
      _friends[i] = other_user._friends[i];
    }
  } else {
    _friends = nullptr;
  }
    
  return *this;
}

User::~User() {
  delete[] _friends; 
}
