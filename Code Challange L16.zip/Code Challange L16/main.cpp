
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include "CLI11.hpp"
#include "barkeep/bar.hpp"

void showProgress(size_t current, size_t total) {
    static barkeep::Bar bar(total);
    bar.update(current);
}

int main(int argc, char** argv) {
    CLI::App app{"Retail Data Analytics"};

    std::string countryFilter;
    bool onlyUK = false;
    std::string filename = "Online Retail.csv";

    app.add_option("-c,--country", countryFilter, "Country filter for transaction count");
    app.add_flag("--only-uk", onlyUK, "Compute total amount only for UK transactions");

    CLI11_PARSE(app, argc, argv);

    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return 1;
    }

    std::string line;
    std::getline(file, line);

    size_t totalLines = 541909;
    size_t currentLine = 0;

    std::map<std::string, int> transactionCount;
    double totalAmount = 0.0;

    while (std::getline(file, line)) {
        currentLine++;
        showProgress(currentLine, totalLines);

        std::stringstream ss(line);
        std::string invoiceNo, stockCode, description, quantityStr, invoiceDate, unitPriceStr, customerID, country;

        std::getline(ss, invoiceNo, ',');
        std::getline(ss, stockCode, ',');
        std::getline(ss, description, ',');
        std::getline(ss, quantityStr, ',');
        std::getline(ss, invoiceDate, ',');
        std::getline(ss, unitPriceStr, ',');
        std::getline(ss, customerID, ',');
        std::getline(ss, country, ',');

        transactionCount[country]++;

        if (!onlyUK || (onlyUK && country == "United Kingdom")) {
            int quantity = std::stoi(quantityStr);
            double unitPrice = std::stod(unitPriceStr);
            totalAmount += quantity * unitPrice;
        }
    }

    std::cout << "\n\nAnálisis de datos:\n";

    if (!countryFilter.empty()) {
        std::cout << "Transacciones en " << countryFilter << ": " << transactionCount[countryFilter] << std::endl;
    } else {
        std::cout << "Transacciones por país:\n";
        for (const auto& [country, count] : transactionCount) {
            std::cout << country << ": " << count << std::endl;
        }
    }

    std::cout << "Monto total de transacciones"
              << (onlyUK ? " en UK" : " en todos los países")
              << ": £" << totalAmount << std::endl;

    return 0;
}
